reduction = function(X,q=2,method='pca',cpve=.9,neighbors=10,rescale=FALSE,Plot=FALSE,...){

	if(rescale == TRUE){
		X = scale(X)
	}

	if(method == 'pca'){
		PCA = stats::prcomp(X,scale=rescale,...)
		Z = PCA$x
		lambdas = PCA$sdev^2
		CPVE = cumsum(lambdas)/sum(lambdas)
		q.star = min(which(CPVE>=cpve))
		print(paste0('The first ',q,' PCs (your selection) carry ',round(CPVE[q]*100,2),'% variability'),quote=FALSE)
		print(paste0('First ',q.star,' PCs required to explain at least ',round(cpve*100,2),'% variability'),quote=FALSE)
		pca.extra = list(q.star=q.star,lambdas=lambdas,CPVE=CPVE)
		res = list(Z=Z[,1:q],full=PCA,pca.extra=pca.extra)
		if(Plot==TRUE){
			par(mfrow=c(1,2))
			plot(CPVE,ylim=c(0,1),pch=16,xlab='number of PCs (q)',ylab='CPVE',main=paste0('q.star = ',q.star))
			abline(h=cpve)
			plot(Z[,1],Z[,2],xlab="PC1",ylab="PC2",col=rgb(0,0,0,.1),pch=16)
		}
	}

	if(method == 'mds'){
		MDS = stats::cmdscale(dist(X), k=q, ...)
		Z = MDS
		res = list(Z=Z,full=MDS)
		if(Plot==TRUE){
			plot(Z[,1],Z[,2],xlab="MDS1",ylab="MDS2",col=rgb(0,0,0,.1),pch=16)
		}
	}

	if(method == 'isomap'){
	  if (!require(vegan)) install.packages('vegan')

		ISOMAP = vegan::isomap(dist(X), ndim=q, k=neighbors, ...)
		Z = ISOMAP$points
		res = list(Z=Z,full=ISOMAP)
		if(Plot==TRUE){
			plot(Z[,1],Z[,2],xlab="ISOMAP1",ylab="ISOMAP2",col=rgb(0,0,0,.1),pch=16)
		}
	}

	if(method == 'tsne'){
	  if (!require(Rtsne)) install.packages('Rtsne')

		TSNE = Rtsne::Rtsne(X, dims=q, perplexity=neighbors, ...)
		Z = TSNE$Y
		res = list(Z=Z,full=TSNE)
		if(Plot==TRUE){
			plot(Z[,1],Z[,2],xlab="tSNE1",ylab="tSNE2",col=rgb(0,0,0,.1),pch=16)
		}
	}

	if(method == 'umap'){
	  if (!require(uwot)) install.packages('uwot')

		UMAP = uwot::umap(X, n_components=q, n_neighbors=neighbors, ...)
		Z = UMAP
		res = list(Z=Z,full=UMAP)
		if(Plot==TRUE){
			plot(Z[,1],Z[,2],xlab="UMAP1",ylab="UMAP2",col=rgb(0,0,0,.1),pch=16)
		}
	}

	if(method == 'ica'){
	  if (!require(fastICA)) install.packages('fastICA')

	  ICA = fastICA::fastICA(X, q, ...)
		Z = ICA$S
		res = list(Z=Z,full=ICA)
		if(Plot==TRUE){
			par(mfrow=c(q,1),mar=c(2,0,0,0))
			for(i in 1:q){
				plot(Z[,i],xlab="",ylab="",type='l',lwd=2,axes=FALSE)
			  axis(1)
			}
		}
	}

return(res)
}





clustering = function(X,K,method='kmeans',linkage='complete',rescale=FALSE,Plot=FALSE,gap.boot=0,...){

	if(rescale == TRUE){
		X = scale(X)
	}

	if(method == 'kmeans'){
		print(paste0('K-means clustering with ',K,' clusters'),quote=FALSE)
		KMEANS = kmeans(X, centers = K,...)
		cluster = KMEANS$cluster
		centroids = KMEANS$centers
		res = list(cluster=cluster,centroids=centroids,full=KMEANS)

		if(Plot==TRUE){
		  if(ncol(X)==2){
		    plot(X,col=cluster,pch=16,xlab='X1',ylab='X2')
		  }
			if(ncol(X)>2){
				Z = stats::prcomp(X,scale=rescale)$x[,1:2]
				plot(Z,col=cluster,pch=16,xlab='PC1',ylab='PC2')
			}
		}

		if(gap.boot>0){
		  if (!require(cluster)) install.packages('cluster')

		  GAP = cluster::clusGap(X, FUNcluster = kmeans, K.max=K, B=gap.boot, ...)
			K.GAP = cluster::maxSE(f = GAP$Tab[, "gap"], SE.f = GAP$Tab[, "SE.sim"])
			print(paste0('GAP (based on K-means) selected ',K.GAP,' clusters'),quote=FALSE)
		}
	}

	if(method == 'hierarchical'){
		HCLUST = hclust(dist(X),method=linkage, ...)
		cluster = cutree(HCLUST,k=K)
		print(paste0('Hierarchical clustering with ',K,' clusters using ',HCLUST$method,' linkage'),quote=FALSE)
		centroids = colMeans(X[cluster==1,])
		if(K>1){
			for(i in 2:K){
				centroids = rbind(centroids,colMeans(X[cluster==i,]))
			}
		}
		res = list(cluster=cluster,centroids=centroids,full=HCLUST)

		if(Plot==TRUE){
			par(mfrow=c(1,2))
			plot(HCLUST,main=paste0(HCLUST$method,' linkage'), xlab="", sub="",cex=1,labels=FALSE,lwd=.2)
			if(ncol(X)==2){
			  plot(X,col=cluster,pch=16,xlab='X1',ylab='X2')
			}
			if(ncol(X)>2){
			  Z = stats::prcomp(X,scale=rescale)$x[,1:2]
			  plot(Z,col=cluster,pch=16,xlab='PC1',ylab='PC2')
			}
		}
	}

return(res)
}







completion = function(XO, method='KNN', notquant=NA, neighbors=10, q=2, reps=100, max.iters=1000, tol=10^-10, Plot=TRUE){

  completion.KNN = function(XO,notquant=NA,neighbors=10,reps=100,Plot=TRUE){
    quant = 1:ncol(XO)
    if(is.numeric(notquant)){
      quant = quant[-notquant]
    }
    completion.KNN0 = function(XO,notquant,neighbors){
      Z = XO
      M = is.na(XO)
      ROWS = which(rowSums(M)>0)
      D = matrix(NA,nr=nrow(XO),nc=nrow(XO))
      distfun = function(x,y) sqrt(sum((x-y)^2,na.rm=TRUE))
      aggfun = lapply(1:ncol(XO),function(i) function(x) mean(x,na.rm=TRUE))
      if(is.numeric(notquant)){
        distfun = function(x,y) sqrt(sum((x[-notquant]-y[-notquant])^2,na.rm=TRUE))
        for(i in notquant){
          aggfun[[i]] = function(x) as.numeric(names(sort(table(x),decreasing=TRUE)))[1]
        }
      }
      for(i in ROWS){
        for(j in 1:nrow(XO)){
          D[i,j] = distfun(XO[i,],XO[j,])
        }
      }
      for(i in ROWS){
        for(j in 1:ncol(XO)){
          if(M[i,j]==TRUE){
            Di.ord = setdiff(order(D[i,]),i)
            Di.ord.ok = Di.ord[!is.na(XO[Di.ord,j])]
            Di.use = Di.ord.ok[1:min(neighbors,length(Di.ord.ok))]
            Z[i,j] = aggfun[[j]](XO[Di.use,j])
          }
        }
      }
      return(Z)
    }

    if(length(neighbors)==1){
      res=list(Z = completion.KNN0(XO,notquant,neighbors))
    }

    if(length(neighbors)>1){
      print('Finding optimal number of neighbors',quote=FALSE)
      LOSS = matrix(NA,nc=length(neighbors),nr=reps)
      pb = txtProgressBar(min = 1, max = reps, style = 3, char='|')
      M = round(is.na(XO))
      PROP.MISS = mean(M)
      for(j in 1:reps){
        M2 = matrix(0,nc=ncol(XO),nr=nrow(XO))
        M2[M==0] = rbinom(sum(M==0),size=1,prob=PROP.MISS)
        XO2 = XO; XO2[M2==1]=NA
        losses = sapply(neighbors,function(k) {
          Zk = completion.KNN0(XO2,notquant=notquant,neighbors=k)
          z.num = Zk[,quant][M2[,quant]==1]
          x.num = XO[,quant][M2[,quant]==1]
          loss = sqrt(sum((x.num-z.num)^2,na.rm=TRUE))
          return(loss)})
        LOSS[j,] = losses
        setTxtProgressBar(pb, j)
      }
      close(pb)
      risk = colMeans(LOSS)
      neighbors.opt = neighbors[which.min(risk)]
      print(paste0('optimal number of neighbors = ',neighbors.opt),quote=FALSE)
      if(Plot==TRUE){
        SDS = sapply(1:length(neighbors),function(i) sd(LOSS[,i]))/sqrt(reps)
        plot(neighbors,risk,type='l',xlab='K',ylab='completion risk',
             main=paste0('Optimal K = ', neighbors.opt),lwd=3,
             ylim=range(c(risk-2*SDS,risk+2*SDS)))
        polygon(c(neighbors,neighbors[length(neighbors):1]), c(risk-2*SDS,(risk+2*SDS)[length(neighbors):1]),border=NA,col=rgb(0,0,0,.2))
        abline(v=neighbors.opt,lty=2)
      }
      res=list(Z=completion.KNN0(XO,notquant,neighbors.opt),risk=risk,neighbors.opt=neighbors.opt,q.opt=NA,notquant=notquant,neighbors=neighbors,q=NA,LOSS=LOSS)
    }
    return(res)
  }


  completion.lowrank = function(XO,q,max.iters=1000,tol=10^-10,reps=10,Plot=TRUE){

    pca.approx = function(X,q){
      Xscaled=scale(X)
      PCA = princomp(Xscaled)
      A = PCA$scores[,1:q]
      B = PCA$loadings[,1:q]
      Xq = A%*%t(B)
      for(i in 1:ncol(Xq)){
        Xq[,i] = Xq[,i]*sd(X[,i])+mean(X[,i])
      }
      return(Xq)
    }

    completion.lowrank0 = function(XO,q,max.iters,tol){
      p=ncol(XO); n=nrow(XO)
      Z = XO; M=is.na(XO)
      for(j in 1:p){
        Z[is.na(Z[,j]),j] = mean(Z[,j],na.rm=TRUE)
      }
      iter=1
      obj = tol+1
      while(iter < max.iters & obj>tol){
        Zq = pca.approx(Z,q)
        obj = sum((Z[M==1] - Zq[M==1])^2)
        Z[M==1] = Zq[M==1]
        iter=iter+1
      }
      return(Z)
    }

    if(length(q)==1){
      res = list(Z=completion.lowrank0(XO=XO,q=q,max.iters=max.iters,tol=tol))
    }

    if(length(q)>1){
      print('Finding optimal rank for Low-Rank completion',quote=FALSE)

      LOSS = matrix(NA,nc=length(q),nr=reps)
      pb = txtProgressBar(min = 1, max = reps, style = 3, char='|')
      M = round(is.na(XO))
      PROP.MISS = mean(M)

      for(j in 1:reps){
        M2 = matrix(0,nc=ncol(XO),nr=nrow(XO))
        M2[M==0] = rbinom(sum(M==0),size=1,prob=PROP.MISS)
        XO2 = XO; XO2[M2==1]=NA
        losses = unlist(lapply(q,function(qq) {
          Zk = completion.lowrank0(XO2,q=qq,max.iters=max.iters,tol=tol)
          z = Zk[M2==1]
          x = XO[M2==1]
          loss = sqrt(sum((x-z)^2))
          return(loss)}
        ))
        LOSS[j,] = losses
        setTxtProgressBar(pb, j)
      }
      close(pb)
      risk = colMeans(LOSS)
      q.opt = q[which.min(risk)]
      print(paste0('optimal rank = ',q.opt),quote=FALSE)
      if(Plot == TRUE){
        SDS = sapply(1:length(q),function(i) sd(LOSS[,i]))/sqrt(reps)
        plot(q,risk,type='l',xlab='q',ylab='completion risk',
             main=paste0('Optimal q = ', q.opt),lwd=3,
             ylim=range(c(risk-2*SDS,risk+2*SDS)))
        polygon(c(q,q[length(q):1]), c(risk-2*SDS,(risk+2*SDS)[length(q):1]),border=NA,col=rgb(0,0,0,.2))
        abline(v=q.opt,lty=2)
      }
      res = list(Z=completion.lowrank0(XO=XO,q=q.opt,max.iters=max.iters,tol=tol),risk=risk,neighbors.opt=NA,q.opt=q.opt,notquant=NA,neighbors=NA,q=q,LOSS=LOSS)
    }
    return(res)
  }

  if(method=='KNN'){
    res = completion.KNN(XO=XO, notquant=notquant, neighbors=neighbors, reps=reps, Plot=Plot)
  }

  if(method=='lowrank'){
    if(is.numeric(notquant)){
      stop("categorical variables are present: please use KNN method")
    }
    res = completion.lowrank(XO=XO, q=q, max.iters=max.iters, tol=tol, reps=reps, Plot=Plot)
  }

  return(res)
}
